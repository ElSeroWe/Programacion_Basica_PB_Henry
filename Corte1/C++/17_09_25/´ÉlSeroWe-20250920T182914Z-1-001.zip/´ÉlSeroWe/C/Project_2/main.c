#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	int age=17;
	
	if (age>=18) {
		printf("You're eligible to vote.\n");
	} else {
		printf("You're not yet eligible to vote.\n");
	}
	return 0;
}
