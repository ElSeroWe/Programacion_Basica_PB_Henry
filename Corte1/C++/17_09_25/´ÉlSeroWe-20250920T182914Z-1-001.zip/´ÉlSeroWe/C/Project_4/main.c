#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	int x = 10;
	int y = 20;
	int max_value;
	max_value = ( x > y ) ? x : y; // If x > y is true, max_value gets x, else it gets y
	printf("The maximum value is: %d\n", max_value);
	return 0;
}
