#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	int number = 10;
	if (number>5){
		printf("The number is grater than 5.\n");
	 }
	return 0;
}
