#include <iostream>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	int number=10;
	
	if (number>5){
		std::cout << "The number is greater than 5.\n";
	} 
	return 0;
}
