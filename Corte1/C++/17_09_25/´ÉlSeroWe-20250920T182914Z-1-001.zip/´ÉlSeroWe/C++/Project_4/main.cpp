#include <iostream>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	int age=17;
	if(age>=18){
		std::cout << "You're elegible to vote.\n";
	} else {
		std::cout << "You're not yet elegible to vote.\n";
	}
	return 0;
}
